import React from 'react';
import { useLiveGemini } from './hooks/useLiveGemini';
import Visualizer from './components/Visualizer';
import Transcript from './components/Transcript';
import { COURSE_CONTENT } from './constants';

// Icons
const MicIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
  </svg>
);

const StopIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  </svg>
);

const CortexIcon = () => (
   <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-400" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
  </svg>
);

function App() {
  const { connectionState, connect, disconnect, volume, messages, error } = useLiveGemini();

  const handleStart = () => {
    connect();
  };

  return (
    <div className="flex flex-col h-screen bg-gray-900 text-white font-sans selection:bg-indigo-500 selection:text-white">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4 bg-gray-800 border-b border-gray-700 shadow-lg z-10">
        <div className="flex items-center gap-3">
            <CortexIcon />
            <div>
                <h1 className="text-xl font-bold tracking-wide">CortexX Tutor</h1>
                <p className="text-xs text-gray-400">Active Recall Coach • Murf Challenge</p>
            </div>
        </div>
        <div className="flex items-center gap-3">
             <div className={`px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-2 ${
                connectionState === 'connected' ? 'bg-green-900/50 text-green-400 border border-green-700' : 
                connectionState === 'connecting' ? 'bg-yellow-900/50 text-yellow-400 border border-yellow-700' :
                connectionState === 'error' ? 'bg-red-900/50 text-red-400 border border-red-700' :
                'bg-gray-700 text-gray-400 border border-gray-600'
             }`}>
                <span className={`w-2 h-2 rounded-full ${
                    connectionState === 'connected' ? 'bg-green-400 animate-pulse' :
                    connectionState === 'connecting' ? 'bg-yellow-400 animate-bounce' :
                    connectionState === 'error' ? 'bg-red-400' :
                    'bg-gray-400'
                }`}></span>
                {connectionState.toUpperCase()}
             </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex overflow-hidden relative">
        
        {/* Left Panel: Content Info */}
        <div className="hidden md:flex w-80 bg-gray-800/50 border-r border-gray-700 flex-col p-6 overflow-y-auto">
            <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">Course Content</h2>
            <div className="space-y-4">
                {COURSE_CONTENT.map(item => (
                    <div key={item.id} className="bg-gray-800 p-4 rounded-xl border border-gray-700 hover:border-indigo-500/50 transition-colors">
                        <h3 className="font-bold text-indigo-400 mb-2">{item.title}</h3>
                        <p className="text-xs text-gray-300 leading-relaxed mb-3">{item.summary}</p>
                        <div className="text-[10px] bg-gray-900/50 p-2 rounded text-gray-400">
                            <span className="font-bold text-gray-500">Sample Q:</span> {item.sample_question}
                        </div>
                    </div>
                ))}
            </div>

            <div className="mt-8">
                <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">Modes</h2>
                <div className="space-y-2">
                    <div className="flex items-center gap-3 p-2 rounded hover:bg-gray-800/50">
                        <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 text-xs font-bold">M</div>
                        <div>
                            <p className="text-sm font-bold">Learn Mode</p>
                            <p className="text-xs text-gray-500">Voice: Matthew</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-3 p-2 rounded hover:bg-gray-800/50">
                        <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400 text-xs font-bold">A</div>
                         <div>
                            <p className="text-sm font-bold">Quiz Mode</p>
                            <p className="text-xs text-gray-500">Voice: Alicia</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-3 p-2 rounded hover:bg-gray-800/50">
                        <div className="w-8 h-8 rounded-full bg-orange-500/20 flex items-center justify-center text-orange-400 text-xs font-bold">K</div>
                         <div>
                            <p className="text-sm font-bold">Teach-Back Mode</p>
                            <p className="text-xs text-gray-500">Voice: Ken</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {/* Center: Interaction */}
        <div className="flex-1 flex flex-col bg-gray-900 relative">
            
            {error && (
                <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-50 bg-red-500/90 text-white px-4 py-2 rounded-lg shadow-lg text-sm">
                    {error}
                </div>
            )}

            <div className="flex-1 flex flex-col max-w-3xl mx-auto w-full">
                <div className="flex-1 relative overflow-hidden flex flex-col">
                     <Transcript messages={messages} />
                     
                     {/* Overlay gradient for cleaner look */}
                     <div className="absolute top-0 left-0 right-0 h-12 bg-gradient-to-b from-gray-900 to-transparent pointer-events-none"></div>
                </div>

                {/* Interaction Area */}
                <div className="p-6 pb-8">
                     <div className="flex flex-col items-center justify-center gap-6">
                         
                         {/* Visualizer */}
                         <div className="w-full max-w-lg relative">
                             <Visualizer volume={volume} active={connectionState === 'connected'} />
                         </div>

                         {/* Controls */}
                         <div className="flex items-center gap-4">
                             {connectionState === 'connected' || connectionState === 'connecting' ? (
                                 <button 
                                    onClick={disconnect}
                                    className="h-16 w-16 rounded-full bg-red-500/20 border border-red-500 text-red-500 hover:bg-red-500 hover:text-white flex items-center justify-center transition-all transform hover:scale-105 shadow-[0_0_20px_rgba(239,68,68,0.3)]"
                                 >
                                     <StopIcon />
                                 </button>
                             ) : (
                                 <button 
                                    onClick={handleStart}
                                    className="h-16 w-16 rounded-full bg-indigo-600 text-white hover:bg-indigo-500 flex items-center justify-center transition-all transform hover:scale-105 shadow-[0_0_30px_rgba(99,102,241,0.5)] relative group"
                                 >
                                     <div className="absolute inset-0 rounded-full border-2 border-white/30 animate-ping opacity-0 group-hover:opacity-100"></div>
                                     <MicIcon />
                                 </button>
                             )}
                         </div>
                         
                         <p className="text-xs text-gray-500 font-medium tracking-wide">
                            {connectionState === 'connected' ? 'LISTENING & SPEAKING' : connectionState === 'error' ? 'CONNECTION FAILED - TRY AGAIN' : 'TAP MIC TO START SESSION'}
                         </p>
                     </div>
                </div>
            </div>

        </div>
      </main>
    </div>
  );
}

export default App;