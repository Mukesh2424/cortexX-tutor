export enum LearningMode {
  STARTUP = 'Startup',
  LEARN = 'Learn',
  QUIZ = 'Quiz',
  TEACH_BACK = 'Teach-Back'
}

export interface CourseContent {
  id: string;
  title: string;
  summary: string;
  sample_question: string;
}

export interface ChatMessage {
  role: 'user' | 'model' | 'system';
  text: string;
  timestamp: Date;
}

export type ConnectionState = 'disconnected' | 'connecting' | 'connected' | 'error';
