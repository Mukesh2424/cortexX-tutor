import React, { useEffect, useRef } from 'react';

interface VisualizerProps {
  volume: number;
  active: boolean;
}

const Visualizer: React.FC<VisualizerProps> = ({ volume, active }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let offset = 0;

    const draw = () => {
      const width = canvas.width;
      const height = canvas.height;
      const centerY = height / 2;

      ctx.clearRect(0, 0, width, height);
      
      if (!active) {
          ctx.beginPath();
          ctx.moveTo(0, centerY);
          ctx.lineTo(width, centerY);
          ctx.strokeStyle = '#4B5563'; // gray-600
          ctx.lineWidth = 2;
          ctx.stroke();
          return;
      }

      ctx.beginPath();
      ctx.moveTo(0, centerY);

      // Create a sine wave that reacts to volume
      // volume is roughly 0.0 to 1.0 (though can peak higher)
      const amplitude = Math.min(volume * 100, height / 2 - 10); 
      const frequency = 0.05;

      for (let x = 0; x < width; x++) {
        const y = centerY + Math.sin(x * frequency + offset) * amplitude;
        ctx.lineTo(x, y);
      }

      ctx.strokeStyle = '#6366F1'; // indigo-500
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.stroke();

      offset += 0.2;
      animationId = requestAnimationFrame(draw);
    };

    draw();

    return () => cancelAnimationFrame(animationId);
  }, [volume, active]);

  return (
    <canvas 
        ref={canvasRef} 
        width={300} 
        height={100} 
        className="w-full h-24 rounded-lg bg-gray-800/50 backdrop-blur-sm"
    />
  );
};

export default Visualizer;
